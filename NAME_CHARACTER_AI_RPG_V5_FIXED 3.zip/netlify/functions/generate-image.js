// netlify/functions/generate-image.js
// 現行のNetlify Functions形式（Request/Response, default export）。
// generate-profile.js がAIで生成した profile.imagePrompt (キャラクター専用プロンプト)を
// バリエーションごとの演出指示と組み合わせ、OpenAIの画像生成APIを実際に呼び出す。

import { getStore } from "@netlify/blobs";

// モデルについて:
// 公式ドキュメント(developers.openai.com/api/docs/guides/image-generation)で
// "With the Images API, choose gpt-image-2 to generate images from text or edit existing images."
// と明記されており、gpt-image-2 が現在の公式推奨モデル。
// アカウントで利用できない場合に備え、Netlifyの環境変数 OPENAI_IMAGE_MODEL で上書きできる。
const IMAGE_MODEL = process.env.OPENAI_IMAGE_MODEL || "gpt-image-2";
// 指定モデルが使えなかった場合の保険。広く使われている安定モデルに1回だけ自動フォールバックする。
const FALLBACK_IMAGE_MODEL = "gpt-image-1";

// 任意のアクセスコード。generate-profile.jsと同じ環境変数を共有する。
const ACCESS_CODE = process.env.SITE_ACCESS_CODE || "";

// 1日あたりの画像生成回数の上限（サイト全体の合計）。画像生成はコストが高いため既定を控えめにしている。
// 既定20回、環境変数 DAILY_IMAGE_LIMIT で変更可。
const DAILY_LIMIT = Number(process.env.DAILY_IMAGE_LIMIT || 20);

function json(status, obj) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function todayKey() {
  return new Date().toISOString().slice(0, 10); // YYYY-MM-DD (UTC基準)
}

// レート制限はベストエフォート。Netlify Blobsが使えない環境でもアプリ全体を壊さないよう、
// エラー時は「制限なし」として通す(fail open)。
async function checkAndIncrementDailyLimit(kind, limit) {
  if (!limit || limit <= 0) return { ok: true };
  try {
    const store = getStore("ntc-rate-limit");
    const key = `${kind}:${todayKey()}`;
    const current = Number((await store.get(key)) || 0);
    if (current >= limit) return { ok: false, current, limit };
    await store.set(key, String(current + 1));
    return { ok: true, current: current + 1, limit };
  } catch (e) {
    console.error("rate limit check failed (failing open):", e);
    return { ok: true };
  }
}

function buildPrompt(profile, variant) {
  const base = (profile.imagePrompt || "").trim() ||
    `${profile.name}, an original RPG character with the "${profile.element || "mystic"}" element, wielding a ${profile.weapon || "signature weapon"}.`;

  const styleBoilerplate = `High-quality Japanese anime/game character-sheet illustration. Cinematic lighting, richly detailed background matching the character's world. Painterly digital art style. Not a real photo. No text, no watermarks, no logos.`;

  const variants = {
    main: `${styleBoilerplate}\n${base}\nFull-body dynamic hero pose, standing confidently, facing slightly toward the viewer, portrait aspect ratio, the character fills most of the frame.`,
    action: `${styleBoilerplate}\n${base}\nDynamic battle/action pose using the weapon or an elemental skill effect, motion lines, glowing elemental energy, dramatic low angle, same character design as the hero pose.`,
    portrait: `${styleBoilerplate}\n${base}\nClose-up bust portrait with an emotional expression matching the character's personality, soft rim lighting, same character design as the hero pose.`,
    ultimate: `${styleBoilerplate}\n${base}\nEpic full-power ultimate-move moment, intense glowing elemental energy erupting around the character, cinematic wide dramatic composition, same character design as the hero pose.`,
  };

  return variants[variant] || variants.main;
}

async function callOpenAIImage(apiKey, model, prompt, size) {
  return fetch("https://api.openai.com/v1/images/generations", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({ model, prompt, size, quality: "medium", n: 1 }),
  });
}

export default async (req) => {
  if (req.method !== "POST") {
    return json(405, { error: "POSTのみ対応" });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return json(500, { error: "サーバーにOPENAI_API_KEYが設定されていません。" });
  }

  let profile, variant, accessCode;
  try {
    const body = await req.json();
    profile = body.profile;
    variant = body.variant || "main";
    accessCode = body.accessCode || "";
    if (!profile || typeof profile !== "object") throw new Error("profile missing");
  } catch (e) {
    return json(400, { error: "リクエストの形式が不正です" });
  }

  if (ACCESS_CODE && accessCode !== ACCESS_CODE) {
    return json(401, { error: "アクセスコードが正しくありません" });
  }

  const limitCheck = await checkAndIncrementDailyLimit("image", DAILY_LIMIT);
  if (!limitCheck.ok) {
    return json(429, { error: "本日のAIイラスト生成回数の上限に達しました。しばらくしてからもう一度お試しください。" });
  }

  const prompt = buildPrompt(profile, variant);
  const size = variant === "portrait" ? "1024x1024" : "1024x1536";

  try {
    let response = await callOpenAIImage(apiKey, IMAGE_MODEL, prompt, size);

    // 指定モデルが存在しない/使えない場合、1回だけ既知の安定モデルにフォールバックする
    if (!response.ok && (response.status === 400 || response.status === 404) && IMAGE_MODEL !== FALLBACK_IMAGE_MODEL) {
      console.error(`image model "${IMAGE_MODEL}" unavailable, falling back to ${FALLBACK_IMAGE_MODEL}`);
      response = await callOpenAIImage(apiKey, FALLBACK_IMAGE_MODEL, prompt, size);
    }

    if (!response.ok) {
      const errText = await response.text();
      return json(502, { error: "AIイラストの生成に失敗しました(OpenAI画像API)", detail: errText.slice(0, 300) });
    }

    const data = await response.json();
    const b64 = data.data?.[0]?.b64_json;
    if (!b64) {
      return json(502, { error: "画像データが返りませんでした" });
    }

    return json(200, { variant, dataUrl: `data:image/png;base64,${b64}` });
  } catch (err) {
    return json(500, { error: "サーバー内部エラーが発生しました", detail: String(err && err.message) });
  }
};

export const config = { path: "/api/generate-image" };
