// netlify/functions/generate-profile.js
// 現行のNetlify Functions形式（Request/Response, default export）。
// 名前から、その名前専用のRPGキャラクター設定(JSON)をOpenAIで生成する。
// OPENAI_API_KEY はサーバー側(process.env)でのみ使用し、ブラウザには一切返さない。

import { getStore } from "@netlify/blobs";

// テキスト生成モデル: 既定は現行の軽量・高速モデル gpt-5.6-luna。
// アカウントによって利用可能なモデルが異なる場合は、Netlifyの環境変数 OPENAI_TEXT_MODEL で
// 上書きできる（例: 従来の gpt-4o-mini に戻す等）。存在しないモデル名を決め打ちしないための対策。
const TEXT_MODEL = process.env.OPENAI_TEXT_MODEL || "gpt-5.6-luna";
// 指定モデルが使えなかった場合の保険。広く使われている安定モデルに1回だけ自動フォールバックする。
const FALLBACK_TEXT_MODEL = "gpt-4o-mini";

// 任意のアクセスコード。Netlifyの環境変数 SITE_ACCESS_CODE を設定すると、
// 一致しないリクエストは拒否される（公開URLの無制限利用・想定外の課金を防ぐため）。
// 未設定の場合はこのチェック自体を行わない。
const ACCESS_CODE = process.env.SITE_ACCESS_CODE || "";

// 1日あたりの設定生成回数の上限（サイト全体の合計）。既定30回、環境変数 DAILY_PROFILE_LIMIT で変更可。
const DAILY_LIMIT = Number(process.env.DAILY_PROFILE_LIMIT || 30);

function json(status, obj) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function todayKey() {
  return new Date().toISOString().slice(0, 10); // YYYY-MM-DD (UTC基準)
}

// レート制限はベストエフォート。Netlify Blobsが使えない環境でもアプリ全体を壊さないよう、
// エラー時は「制限なし」として通す(fail open)。
async function checkAndIncrementDailyLimit(kind, limit) {
  if (!limit || limit <= 0) return { ok: true };
  try {
    const store = getStore("ntc-rate-limit");
    const key = `${kind}:${todayKey()}`;
    const current = Number((await store.get(key)) || 0);
    if (current >= limit) return { ok: false, current, limit };
    await store.set(key, String(current + 1));
    return { ok: true, current: current + 1, limit };
  } catch (e) {
    console.error("rate limit check failed (failing open):", e);
    return { ok: true };
  }
}

const SYSTEM_PROMPT = `あなたはスマホ向けRPGゲームのキャラクターデザイナーです。
ユーザーから渡された「名前」だけを手がかりに、その名前の響き・漢字から連想される意味・雰囲気・音から、
その名前だけのオリジナルキャラクターを1体、日本語で創作してください。

絶対条件:
- 同じ名前が来ない限り、毎回まったく異なる属性・見た目・性格・技・世界観を創作すること。
  特定の既存キャラクター(千花・龍平・優羽などの例)を再利用したり真似したりしないこと。
- 出力は指定のJSON形式のみ。前置き・説明・Markdownのコードフェンスは一切つけない。
- element(属性)に応じて colorTheme を必ず変えること。例: 火=赤/橙, 氷=青/白, 雷=紫/黄, 自然=緑, 闇=黒/紫, 光=白/金。他の属性を創作してもよい。
- rarity は "N" "R" "SR" "SSR" "UR" のいずれか。
- stats は 1〜100 の整数。合計は220〜340程度に収める。
- skills は必ず3個。それぞれ異なる効果の通常スキルにすること。
- imagePrompt は画像生成AI(GPT Image)にそのまま渡す、英語の1段落の詳細なプロンプトにすること。
  年齢感・性別表現・髪型・髪色・瞳の色・服装・武器・属性・表情・雰囲気・世界観の空気感を
  具体的な英単語で書くこと。"anime character" のような曖昧な一言だけの記述は禁止。
  実在の人物・既存の版権キャラクターの名前は書かないこと。

JSON形式:
{
  "name": "表示名",
  "reading": "ひらがな読み",
  "romaji": "ROMAJI NAME",
  "catchphrase": "キャッチコピー(短文)",
  "quote": "決め台詞",
  "element": "属性",
  "weapon": "武器",
  "battleType": "戦闘タイプ(例: アタッカー/ヒーラー/タンク等)",
  "rarity": "N|R|SR|SSR|UR",
  "stats": {"hp": 0, "atk": 0, "def": 0, "spd": 0, "crit": 0},
  "personality": "性格の説明",
  "introduction": "キャラクター紹介文(3〜4文)",
  "likes": "好きなもの",
  "dislikes": "苦手なもの",
  "dream": "夢",
  "goal": "目的",
  "episode": "こんなエピソードがあるよ、という固有の小話(3〜4文)",
  "world": "このキャラクターが生きる世界観の説明(3〜4文)",
  "skills": [
    {"name": "スキル1の名前", "description": "効果の説明"},
    {"name": "スキル2の名前", "description": "効果の説明"},
    {"name": "スキル3の名前", "description": "効果の説明"}
  ],
  "passive": {"name": "パッシブ名", "description": "説明"},
  "ultimate": {"name": "必殺技名", "description": "説明"},
  "colorTheme": {"primary": "#rrggbb", "secondary": "#rrggbb", "accent": "#rrggbb"},
  "appearance": {
    "age": "年齢感",
    "gender": "性別表現",
    "hair": "髪型・髪色",
    "eyes": "瞳の色",
    "outfit": "服装の特徴",
    "mood": "全体の雰囲気・オーラ"
  },
  "imagePrompt": "English, one detailed paragraph for an image generation AI, covering age, gender presentation, hairstyle, hair color, eye color, outfit, weapon, element-themed effects, expression, mood, and world atmosphere."
}`;

// OpenAIが返したJSONは信用しすぎない。欠落・型崩れ(数値が文字列など)を補正してから返す。
function sanitizeProfile(raw, fallbackName) {
  const p = raw && typeof raw === "object" ? raw : {};
  const str = (v, def = "") => (typeof v === "string" && v.trim() ? v.trim() : def);
  const num = (v, def = 50) => {
    const n = Number(v);
    return Number.isFinite(n) ? Math.max(1, Math.min(100, Math.round(n))) : def;
  };
  const hex = (v, def) => (typeof v === "string" && /^#[0-9a-fA-F]{6}$/.test(v.trim()) ? v.trim() : def);

  const statsIn = p.stats && typeof p.stats === "object" ? p.stats : {};
  const skillsIn = Array.isArray(p.skills) ? p.skills.slice(0, 3) : [];
  while (skillsIn.length < 3) skillsIn.push({});

  const rarity = ["N", "R", "SR", "SSR", "UR"].includes(p.rarity) ? p.rarity : "SR";
  const theme = p.colorTheme && typeof p.colorTheme === "object" ? p.colorTheme : {};

  return {
    name: str(p.name, fallbackName),
    reading: str(p.reading, ""),
    romaji: str(p.romaji, ""),
    catchphrase: str(p.catchphrase, ""),
    quote: str(p.quote, ""),
    element: str(p.element, "無属性"),
    weapon: str(p.weapon, "武器"),
    battleType: str(p.battleType, "アタッカー"),
    rarity,
    stats: {
      hp: num(statsIn.hp), atk: num(statsIn.atk), def: num(statsIn.def),
      spd: num(statsIn.spd), crit: num(statsIn.crit, 20),
    },
    personality: str(p.personality, ""),
    introduction: str(p.introduction, ""),
    likes: str(p.likes, ""),
    dislikes: str(p.dislikes, ""),
    dream: str(p.dream, ""),
    goal: str(p.goal, ""),
    episode: str(p.episode, ""),
    world: str(p.world, ""),
    skills: skillsIn.map((s, i) => ({
      name: str(s && s.name, `スキル${i + 1}`),
      description: str(s && s.description, ""),
    })),
    passive: { name: str(p.passive && p.passive.name, "パッシブ"), description: str(p.passive && p.passive.description, "") },
    ultimate: { name: str(p.ultimate && p.ultimate.name, "必殺技"), description: str(p.ultimate && p.ultimate.description, "") },
    colorTheme: {
      primary: hex(theme.primary, "#3a6df0"),
      secondary: hex(theme.secondary, "#0b1030"),
      accent: hex(theme.accent, "#ffd76a"),
    },
    appearance: {
      age: str(p.appearance && p.appearance.age, ""),
      gender: str(p.appearance && p.appearance.gender, ""),
      hair: str(p.appearance && p.appearance.hair, ""),
      eyes: str(p.appearance && p.appearance.eyes, ""),
      outfit: str(p.appearance && p.appearance.outfit, ""),
      mood: str(p.appearance && p.appearance.mood, ""),
    },
    imagePrompt: str(p.imagePrompt, `${str(p.name, fallbackName)}, an original RPG character illustration.`),
  };
}

async function callOpenAI(apiKey, model, name) {
  return fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({
      model,
      response_format: { type: "json_object" },
      temperature: 1.05,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: `キャラクター名: 「${name}」` },
      ],
    }),
  });
}

export default async (req) => {
  if (req.method !== "POST") {
    return json(405, { error: "POSTのみ対応" });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return json(500, { error: "サーバーにOPENAI_API_KEYが設定されていません。Netlifyの環境変数を確認してください。" });
  }

  let name, accessCode;
  try {
    const body = await req.json();
    name = (body.name || "").trim();
    accessCode = body.accessCode || "";
  } catch (e) {
    return json(400, { error: "リクエストの形式が不正です" });
  }

  if (ACCESS_CODE && accessCode !== ACCESS_CODE) {
    return json(401, { error: "アクセスコードが正しくありません" });
  }

  if (!name || name.length > 20) {
    return json(400, { error: "名前は1〜20文字で入力してください" });
  }

  const limitCheck = await checkAndIncrementDailyLimit("profile", DAILY_LIMIT);
  if (!limitCheck.ok) {
    return json(429, { error: "本日のキャラクター生成回数の上限に達しました。しばらくしてからもう一度お試しください。" });
  }

  try {
    let response = await callOpenAI(apiKey, TEXT_MODEL, name);

    // 指定モデルが存在しない/使えない場合、1回だけ既知の安定モデルにフォールバックする
    if (!response.ok && (response.status === 400 || response.status === 404) && TEXT_MODEL !== FALLBACK_TEXT_MODEL) {
      console.error(`text model "${TEXT_MODEL}" unavailable, falling back to ${FALLBACK_TEXT_MODEL}`);
      response = await callOpenAI(apiKey, FALLBACK_TEXT_MODEL, name);
    }

    if (!response.ok) {
      const errText = await response.text();
      return json(502, { error: "キャラクター設定の生成に失敗しました(OpenAI API)", detail: errText.slice(0, 300) });
    }

    const data = await response.json();
    const raw = data.choices?.[0]?.message?.content;
    if (!raw) {
      return json(502, { error: "OpenAIから空の応答が返りました" });
    }

    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (e) {
      return json(502, { error: "設定データの解析に失敗しました(JSON形式エラー)" });
    }

    const profile = sanitizeProfile(parsed, name);
    return json(200, { profile });
  } catch (err) {
    return json(500, { error: "サーバー内部エラーが発生しました", detail: String(err && err.message) });
  }
};

export const config = { path: "/api/generate-profile" };
