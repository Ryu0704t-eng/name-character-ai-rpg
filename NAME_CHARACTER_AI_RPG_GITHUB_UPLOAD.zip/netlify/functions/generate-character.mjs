import OpenAI from "openai";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const jsonHeaders = {
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store",
};

function response(statusCode, body) {
  return { statusCode, headers: jsonHeaders, body: JSON.stringify(body) };
}

export default async (req) => {
  if (req.httpMethod !== "POST") return response(405, { error: "POST only" });
  if (!process.env.OPENAI_API_KEY) return response(500, { error: "OPENAI_API_KEY がNetlifyに設定されていません。" });

  try {
    const { name } = JSON.parse(req.body || "{}");
    if (!name || typeof name !== "string") return response(400, { error: "名前を入力してください。" });

    const textPrompt = `
あなたは日本の本格的なアニメRPGのキャラクターデザイナーです。
ユーザーが入力した名前「${name}」から、完全オリジナルのキャラクター設定を作ってください。
「千花」「龍平」「優羽」のように、名前に合った自然な読み・雰囲気を考えますが、既存キャラクターのコピーはしません。
日本語でJSONだけを返してください。
キー:
name, roman, personality, background, attribute, weapon, role, rarity, likes, goal, quote,
stats(HP,攻撃,防御,速度,会心の5数値 100〜999),
skills(3個の{name,description}),
ultimate({name,description}),
episode,
imagePrompt
imagePromptは画像生成AI向けの英語プロンプト。美麗なアニメRPGキャラクター、全身が見える、映画的ライティング、キャラクターの属性・武器・衣装・表情・背景まで具体化。画像内に文字・ロゴ・UI・透かしは入れない。
`;

    const completion = await client.chat.completions.create({
      model: "gpt-5.6-luna",
      messages: [
        { role: "system", content: "Return valid JSON only. No markdown." },
        { role: "user", content: textPrompt }
      ],
      response_format: { type: "json_object" }
    });

    const character = JSON.parse(completion.choices?.[0]?.message?.content || "{}");
    if (!character.imagePrompt) throw new Error("キャラクター設定の生成に失敗しました。");

    const image = await client.images.generate({
      model: "gpt-image-2",
      prompt: character.imagePrompt,
      size: "1024x1024",
      quality: "medium",
      n: 1
    });

    const b64 = image.data?.[0]?.b64_json;
    if (!b64) throw new Error("画像生成結果が取得できませんでした。");

    character.image = `data:image/png;base64,${b64}`;
    delete character.imagePrompt;

    return response(200, character);
  } catch (err) {
    console.error(err);
    return response(500, { error: err?.message || "AI生成中にエラーが発生しました。" });
  }
};