# NAME→CHARACTER AI RPG

名前を入力すると、Netlify Function経由でAIがキャラクター設定を作り、
GPT Image 2で完全新規のキャラクター画像を生成します。

## Netlify設定
1. このフォルダをNetlifyへデプロイ
2. Site configuration → Environment variables
3. `OPENAI_API_KEY` に自分のOpenAI APIキーを設定
4. 再デプロイ

APIキーはHTMLに書かず、必ずNetlifyの環境変数に入れてください。

画像生成はOpenAI Image APIの `gpt-image-2` を使用します。
