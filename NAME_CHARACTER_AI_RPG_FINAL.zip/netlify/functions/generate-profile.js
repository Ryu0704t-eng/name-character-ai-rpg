// netlify/functions/generate-profile.js
// 現行のNetlify Functions形式（Request/Response, default export）。
// 名前から、その名前専用のRPGキャラクター設定(JSON)をOpenAIで生成する。
// OPENAI_API_KEY はサーバー側(process.env)でのみ使用し、ブラウザには一切返さない。

function json(status, obj) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

const SYSTEM_PROMPT = `あなたはスマホ向けRPGゲームのキャラクターデザイナーです。
ユーザーから渡された「名前」だけを手がかりに、その名前の響き・漢字から連想される意味・雰囲気・音から、
その名前だけのオリジナルキャラクターを1体、日本語で創作してください。

絶対条件:
- 同じ名前が来ない限り、毎回まったく異なる属性・見た目・性格・技・世界観を創作すること。
  特定の既存キャラクター(千花・龍平・優羽などの例)を再利用したり真似したりしないこと。
- 出力は指定のJSON形式のみ。前置き・説明・Markdownのコードフェンスは一切つけない。
- element(属性)に応じて colorTheme を必ず変えること。例: 火=赤/橙, 氷=青/白, 雷=紫/黄, 自然=緑, 闇=黒/紫, 光=白/金。他の属性を創作してもよい。
- rarity は "N" "R" "SR" "SSR" "UR" のいずれか。
- stats は 1〜100 の整数。合計は220〜340程度に収める。
- skills は必ず3個。それぞれ異なる効果の通常スキルにすること。
- imagePrompt は画像生成AI(GPT Image)にそのまま渡す、英語の1段落の詳細なプロンプトにすること。
  年齢感・性別表現・髪型・髪色・瞳の色・服装・武器・属性・表情・雰囲気・世界観の空気感を
  具体的な英単語で書くこと。"anime character" のような曖昧な一言だけの記述は禁止。
  実在の人物・既存の版権キャラクターの名前は書かないこと。

JSON形式:
{
  "name": "表示名",
  "reading": "ひらがな読み",
  "romaji": "ROMAJI NAME",
  "catchphrase": "キャッチコピー(短文)",
  "quote": "決め台詞",
  "element": "属性",
  "weapon": "武器",
  "battleType": "戦闘タイプ(例: アタッカー/ヒーラー/タンク等)",
  "rarity": "N|R|SR|SSR|UR",
  "stats": {"hp": 0, "atk": 0, "def": 0, "spd": 0, "crit": 0},
  "personality": "性格の説明",
  "introduction": "キャラクター紹介文(3〜4文)",
  "likes": "好きなもの",
  "dislikes": "苦手なもの",
  "dream": "夢",
  "goal": "目的",
  "episode": "こんなエピソードがあるよ、という固有の小話(3〜4文)",
  "world": "このキャラクターが生きる世界観の説明(3〜4文)",
  "skills": [
    {"name": "スキル1の名前", "description": "効果の説明"},
    {"name": "スキル2の名前", "description": "効果の説明"},
    {"name": "スキル3の名前", "description": "効果の説明"}
  ],
  "passive": {"name": "パッシブ名", "description": "説明"},
  "ultimate": {"name": "必殺技名", "description": "説明"},
  "colorTheme": {"primary": "#rrggbb", "secondary": "#rrggbb", "accent": "#rrggbb"},
  "appearance": {
    "age": "年齢感",
    "gender": "性別表現",
    "hair": "髪型・髪色",
    "eyes": "瞳の色",
    "outfit": "服装の特徴",
    "mood": "全体の雰囲気・オーラ"
  },
  "imagePrompt": "English, one detailed paragraph for an image generation AI, covering age, gender presentation, hairstyle, hair color, eye color, outfit, weapon, element-themed effects, expression, mood, and world atmosphere."
}`;

export default async (req) => {
  if (req.method !== "POST") {
    return json(405, { error: "POSTのみ対応" });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return json(500, { error: "サーバーにOPENAI_API_KEYが設定されていません。Netlifyの環境変数を確認してください。" });
  }

  let name;
  try {
    const body = await req.json();
    name = (body.name || "").trim();
  } catch (e) {
    return json(400, { error: "リクエストの形式が不正です" });
  }

  if (!name || name.length > 20) {
    return json(400, { error: "名前は1〜20文字で入力してください" });
  }

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        response_format: { type: "json_object" },
        temperature: 1.05,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: `キャラクター名: 「${name}」` },
        ],
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      return json(502, { error: "キャラクター設定の生成に失敗しました(OpenAI API)", detail: errText.slice(0, 300) });
    }

    const data = await response.json();
    const raw = data.choices?.[0]?.message?.content;
    if (!raw) {
      return json(502, { error: "OpenAIから空の応答が返りました" });
    }

    let profile;
    try {
      profile = JSON.parse(raw);
    } catch (e) {
      return json(502, { error: "設定データの解析に失敗しました(JSON形式エラー)" });
    }

    if (!profile.name || !profile.imagePrompt) {
      return json(502, { error: "生成された設定データが不完全でした" });
    }

    return json(200, { profile });
  } catch (err) {
    return json(500, { error: "サーバー内部エラーが発生しました", detail: String(err && err.message) });
  }
};

export const config = { path: "/api/generate-profile" };
