// netlify/functions/generate-image.js
// 現行のNetlify Functions形式（Request/Response, default export）。
// generate-profile.js がAIで生成した profile.imagePrompt (キャラクター専用プロンプト)を
// バリエーションごとの演出指示と組み合わせ、OpenAIの画像生成APIを実際に呼び出す。
//
// モデルについて:
// ユーザー指定は "gpt-image-2" だったが、OpenAI公式ドキュメント(developers.openai.com/api/docs/guides/image-generation)
// で "With the Images API, choose gpt-image-2.5-sunburst to generate images from text or edit existing images."
// と明記されており、gpt-image-2.5-sunburst が gpt-image-2 の後継として現在の公式推奨モデル。
// そのためこちらを使用する。将来また変わった場合はこの1箇所のモデル名を差し替えるだけでよい。

const IMAGE_MODEL = "gpt-image-2.5-sunburst";

function json(status, obj) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function buildPrompt(profile, variant) {
  const base = (profile.imagePrompt || "").trim() ||
    `${profile.name}, an original RPG character with the "${profile.element || "mystic"}" element, wielding a ${profile.weapon || "signature weapon"}.`;

  const styleBoilerplate = `High-quality Japanese anime/game character-sheet illustration. Cinematic lighting, richly detailed background matching the character's world. Painterly digital art style. Not a real photo. No text, no watermarks, no logos.`;

  const variants = {
    main: `${styleBoilerplate}\n${base}\nFull-body dynamic hero pose, standing confidently, facing slightly toward the viewer, portrait aspect ratio, the character fills most of the frame.`,
    action: `${styleBoilerplate}\n${base}\nDynamic battle/action pose using the weapon or an elemental skill effect, motion lines, glowing elemental energy, dramatic low angle, same character design as the hero pose.`,
    portrait: `${styleBoilerplate}\n${base}\nClose-up bust portrait with an emotional expression matching the character's personality, soft rim lighting, same character design as the hero pose.`,
    ultimate: `${styleBoilerplate}\n${base}\nEpic full-power ultimate-move moment, intense glowing elemental energy erupting around the character, cinematic wide dramatic composition, same character design as the hero pose.`,
  };

  return variants[variant] || variants.main;
}

export default async (req) => {
  if (req.method !== "POST") {
    return json(405, { error: "POSTのみ対応" });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return json(500, { error: "サーバーにOPENAI_API_KEYが設定されていません。" });
  }

  let profile, variant;
  try {
    const body = await req.json();
    profile = body.profile;
    variant = body.variant || "main";
    if (!profile || typeof profile !== "object") throw new Error("profile missing");
  } catch (e) {
    return json(400, { error: "リクエストの形式が不正です" });
  }

  const prompt = buildPrompt(profile, variant);
  const size = variant === "portrait" ? "1024x1024" : "1024x1536";

  try {
    const response = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: IMAGE_MODEL,
        prompt,
        size,
        quality: "medium",
        output_format: "webp",
        output_compression: 78,
        n: 1,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      return json(502, { error: "AIイラストの生成に失敗しました(OpenAI画像API)", detail: errText.slice(0, 300) });
    }

    const data = await response.json();
    const b64 = data.data?.[0]?.b64_json;
    if (!b64) {
      return json(502, { error: "画像データが返りませんでした" });
    }

    return json(200, { variant, dataUrl: `data:image/webp;base64,${b64}` });
  } catch (err) {
    return json(500, { error: "サーバー内部エラーが発生しました", detail: String(err && err.message) });
  }
};

export const config = { path: "/api/generate-image" };
