# NAME → CHARACTER AI RPG

名前を入力すると、AI(OpenAI API)がその場でオリジナルのキャラクター設定と画像を生成する、
iPhone Safari対応のブラウザRPGです。生成したキャラクターは保存して、ターン制バトルで使えます。

## 構成

```
ブラウザ (public/index.html)
   ↓ fetch("/api/generate-profile") / fetch("/api/generate-image")
Netlify Functions (netlify/functions/*.js)
   ↓ OpenAIのAPIキーはここでだけ使用（process.env.OPENAI_API_KEY）
OpenAI API (chat.completions / images.generations)
```

- `netlify/functions/generate-profile.js` … 名前から、その名前専用のRPGキャラクター設定(JSON)を
  chat.completionsで生成。名前(読み/ローマ字)・キャッチコピー・決め台詞・属性・武器・戦闘タイプ・
  レアリティ・能力値・性格・紹介・好き/苦手・夢・目的・エピソード・世界観・スキル3種・パッシブ・
  必殺技・画像生成用プロンプト(imagePrompt)を出力させる。
- `netlify/functions/generate-image.js` … `profile.imagePrompt`（AIがキャラクターごとに書いた
  英語の詳細プロンプト）に、カットの種類(メイン/バトル/表情/必殺技)ごとの演出指示を足して
  OpenAI Images APIを実際に呼び出す。画像モデルは `gpt-image-2.5-sunburst`。生成画像はWebP圧縮で返し、Netlifyのレスポンス容量を抑える。
- `public/index.html` … タイトル→名前入力→生成中演出→キャラクター詳細画面→保存一覧→バトルまでの全画面。

**OPENAI_API_KEYはブラウザに一切渡らず、Netlify Functions内でのみ使用されます。**
関数は Netlify の現行推奨形式（`export default async (req) => new Response(...)`、Request/Response
ベース）で実装しており、レガシーな `exports.handler` 形式は使用していません。各関数は
`export const config = { path: "/api/..." }` で自身のURLを直接公開します。

## 画面構成

1. タイトル（はじめる／保存したキャラクターを見る）
2. 名前入力
3. 生成中（メッセージが自動でローテーションし、経過秒数を表示。偽の残り時間は表示しません）
4. キャラクター詳細（メイン画像・プロフィール・能力値・スキル3種・パッシブ・必殺技・世界観・
   エピソード・追加カットのギャラリー・保存/バトルボタン）
5. 保存キャラクター一覧（サムネイル付きグリッド、タップで詳細再表示、×で削除）
6. バトル（通常攻撃／スキル／必殺技(3ゲージで使用可)のターン制。能力値がダメージ計算に反映される）

## デプロイ手順

1. このフォルダをGitHubリポジトリにpushするか、Netlifyに直接ドラッグ&ドロップします。
2. Netlifyのサイト設定 → **Site configuration → Environment variables** で
   `OPENAI_API_KEY` を追加します（あなたのOpenAI APIキー。これ以外の環境変数は不要です）。
3. Build settings はこのままで動きます（`netlify.toml`に設定済み、追加の依存パッケージなし）。
   - Publish directory: `public`
   - Functions directory: `netlify/functions`
4. デプロイ後、発行されたURLをiPhoneのSafariで開いて動作確認してください。

## ローカルで確認する場合

```bash
npm install -g netlify-cli
netlify env:set OPENAI_API_KEY "sk-xxxxxxxx"
netlify dev
```

## モックモード（AI通信なしのテスト表示）

タイトル画面下部の「🧪 モックモードで画面を確認する」を押すと、OpenAI APIにもNetlify Functionsにも
一切通信せず、クライアント側だけで用意したダミーデータでゲームを最後まで操作できます。

- 名前を入力して「キャラクター生成」を押すと、`/api/generate-profile` や `/api/generate-image` は
  呼ばれず、代わりに `mockFetchProfile()` / `mockFetchImage()` がダミーのプロフィールと
  「MOCK」と書かれたプレースホルダー画像を返します（本物のAI画像ではないことが画像上にも
  はっきり表示されます）。
- 画面遷移・ローディング演出・キャラクター詳細のレイアウト・追加カットの遅延生成・保存・
  保存一覧・バトル（通常攻撃/スキル/必殺技）まで、本番と全く同じ画面・同じコードパスで
  確認できます。
- モックモード中は、生成中画面とキャラクター詳細画面に赤い「🧪 MOCKモード」バッジが表示され、
  本物の生成結果と混同しないようになっています。保存したテストキャラクターも一覧で
  🧪マーク付きで区別されます。
- タイトル画面に戻る、または「はじめる」を押すと自動的にモックモードは解除され、
  以降は必ず本番のOpenAI API通信に戻ります。**本番モードでモックデータが使われることはありません。**
- ローカルでの確認例: `netlify dev` を起動せず、`public/index.html` を直接ブラウザで開くだけでも
  モックモードは動作します（サーバー不要・APIキー不要）。実際のAI生成を試す場合のみ
  `netlify dev`（`OPENAI_API_KEY`設定済み）またはデプロイ先URLが必要です。

## タイムアウト・容量対策

- 名前入力後は **メイン画像1枚だけ** を必須生成し、それが完了した時点でキャラクター画面を表示します。
  バトル/表情/必殺技の3カットは、画面表示後にバックグラウンドで1枚ずつ個別リクエストとして
  生成します。1リクエストにつき画像1枚しか生成しないため、Netlifyの同期Functionsの実行時間上限に
  引っかかりにくい構成です。
- 追加カットの生成に失敗しても、そのスロットだけに「失敗しました／再試行」を表示し、メイン画像や
  他の情報には一切影響しません（キャラクター本体の完成扱いは取り消しません）。
- 保存(localStorage)は最大6体まで、かつ**メイン画像のみ**を保存します（追加カットは保存しません）。
  容量超過(QuotaExceededError)時は古い保存から自動的に削除して再試行します。

## 実施した確認（このコンテナ内でできる範囲）

このサンドボックスには外部ネットワークアクセスがなく、実際のNetlifyデプロイやOpenAI APIへの
本番通信をこちらで行うことはできません。そのため以下のコード検証を行いました。

- `node --check` による2つのNetlify Functionsファイルの構文チェック → エラーなし
- `public/index.html` 内のJavaScriptから参照している全DOM ID(`$("...")`)がHTML側に実在するかの
  突き合わせ → 不一致なし
- `data-back` の遷移先が有効な画面IDであることの確認
- HTMLの `<section>` / `<div>` の開閉タグ数が一致することの確認
- `package.json` は外部依存パッケージを持たないため `npm install` は即座に成立します

**未確認（実機・実デプロイが必要なもの）**:
- Netlifyへの実際のデプロイとビルド成立
- OpenAI APIキーを使った実際のchat.completions / images.generations呼び出しの成功可否
- iPhone Safari実機でのタップ操作・レイアウト崩れの目視確認

これらはお手元でデプロイ後にご確認いただき、エラーが出た場合はNetlifyのFunctionログと
一緒に共有していただければ、原因を特定して修正します。

## デプロイ後のテスト手順（本番モード）

1. まずモックモードで画面遷移・保存・バトル・レイアウトが問題ないことを確認する
   （AI通信なしで完結するので、これはデプロイ前のローカルでも可能）。
2. Netlifyに `OPENAI_API_KEY` を設定してデプロイする。
3. 発行されたURLをiPhone Safariで開き、タイトル画面の「はじめる」（モックではない方）から
   「龍平」と入力して生成する。
4. 「設定を生成中…」の間に `/api/generate-profile` が200を返すこと、続けて
   「AIイラストを生成中…」の間に `/api/generate-image` (variant: main) が200を返すことを、
   Safariの開発者ツールまたはNetlifyのFunctionログで確認する。
5. 龍平のキャラクター画面が表示されたら、同様に「千花」「優羽」でも生成し、
   **3人とも設定・メイン画像がそれぞれ異なること**（同じ画像の使い回しになっていないこと）を確認する。
6. キャラクター画面で追加カット(バトル/表情/必殺技)が表示後にバックグラウンドで生成されること、
   Wi-Fiを切るなどして意図的に失敗させた場合はそのスロットだけ「失敗しました／再試行」に
   なることを確認する。
7. 「保存」→「保存したキャラクターを見る」で一覧に表示され、タップで詳細画面に戻れることを確認する。
8. 「バトルへ」で通常攻撃/スキル/必殺技(ゲージ3で解禁)を使い、HPが能力値に応じて増減し、
   勝敗が表示されることを確認する。
9. OpenAIのAPIキーを一時的に外すなど意図的にエラーを起こし、画面が白くならず
   「キャラクター生成に失敗しました」＋「もう一度生成」が出ることを確認する。


## 今回の本番向け修正

- 画像モデルは OpenAI の `gpt-image-2.5-sunburst` を使用します。
- GPT Image 系で利用可能な `output_format: "webp"` と `output_compression` を使い、画像をWebPで返します。これにより、Base64画像を含むNetlify Functionレスポンスが大きくなりすぎるリスクを下げています。
- ブラウザへ返す画像は `data:image/webp;base64,...` として表示します。固定画像やサンプル画像へのフォールバックは本番生成処理にはありません。
